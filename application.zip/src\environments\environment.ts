// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyBZdlBkLuCt11sKSsqz0A1FGP37UmVWh8Y",
    authDomain: "transaction-tracker-3a45c.firebaseapp.com",
    databaseURL: "https://transaction-tracker-3a45c.firebaseio.com",
    projectId: "transaction-tracker-3a45c",
    storageBucket: "transaction-tracker-3a45c.appspot.com",
    messagingSenderId: "1014394756343"
  }
};
