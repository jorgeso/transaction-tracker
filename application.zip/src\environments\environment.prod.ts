export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBZdlBkLuCt11sKSsqz0A1FGP37UmVWh8Y",
    authDomain: "transaction-tracker-3a45c.firebaseapp.com",
    databaseURL: "https://transaction-tracker-3a45c.firebaseio.com",
    projectId: "transaction-tracker-3a45c",
    storageBucket: "transaction-tracker-3a45c.appspot.com",
    messagingSenderId: "1014394756343"
  }
};
